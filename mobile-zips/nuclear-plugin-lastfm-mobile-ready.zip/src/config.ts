export const LASTFM_API_URL = 'https://ws.audioscrobbler.com/2.0/';
export const LASTFM_AUTH_URL = 'https://www.last.fm/api/auth/';

const decode = (encoded: string): string => atob(encoded);
export const LASTFM_API_KEY = decode('MmI3NWRjYjI5MWUyYjBjOWEyYzk5NGFjYTUyMmFjMTQ=');
export const LASTFM_API_SECRET = decode('MmVlNDllMzVmMDhiODM3ZDQzYjI4MjQxOTgxNzFmYzg=');

export const SETTINGS = {
  SCROBBLING_ENABLED: 'scrobbling-enabled',
  AUTH_WIDGET: 'lastfm-auth',
} as const;

export const WIDGET_ID = 'lastfm-auth-widget';
