import type { FetchFunction } from '@nuclearplayer/plugin-sdk';

import { LASTFM_API_KEY, LASTFM_API_SECRET, LASTFM_API_URL } from './config';
import { createApiSignature } from './signature';
import type {
  LastFmAuthToken,
  LastFmError,
  LastFmNowPlayingResponse,
  LastFmScrobbleResponse,
  LastFmSession,
  LastFmSimilarArtistsResponse,
  LastFmSimilarTracksResponse,
  LastFmTopTracksResponse,
} from './types';

const optionalParams = (
  params: Record<string, string | undefined>,
): Record<string, string> =>
  Object.fromEntries(
    Object.entries(params).filter(([, value]) => value != null),
  ) as Record<string, string>;

const isLastFmError = (data: Record<string, unknown>): data is LastFmError =>
  'error' in data && typeof data.error === 'number';

export class LastFmClient {
  #fetch: FetchFunction;

  constructor(fetchFn: FetchFunction) {
    this.#fetch = fetchFn;
  }

  async #get<T>(
    params: Record<string, string>,
    errorContext: string,
  ): Promise<T> {
    const allParams = { ...params, api_key: LASTFM_API_KEY, format: 'json' };
    const url = `${LASTFM_API_URL}?${new URLSearchParams(allParams).toString()}`;
    const response = await this.#fetch(url);
    const data = (await response.json()) as Record<string, unknown>;

    if (isLastFmError(data)) {
      throw new Error(
        `Last.fm ${errorContext} error ${data.error}: ${data.message}`,
      );
    }

    return data as T;
  }

  async #signedGet<T>(
    baseParams: Record<string, string>,
    errorContext: string,
  ): Promise<T> {
    const signature = createApiSignature(baseParams, LASTFM_API_SECRET);
    return this.#get<T>({ ...baseParams, api_sig: signature }, errorContext);
  }

  async #signedPost<T>(
    baseParams: Record<string, string>,
    errorContext: string,
  ): Promise<T> {
    const signature = createApiSignature(baseParams, LASTFM_API_SECRET);
    const params = { ...baseParams, api_sig: signature, format: 'json' };

    const response = await this.#fetch(LASTFM_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params).toString(),
    });

    const data = (await response.json()) as Record<string, unknown>;

    if (isLastFmError(data)) {
      throw new Error(
        `Last.fm ${errorContext} error ${data.error}: ${data.message}`,
      );
    }

    return data as T;
  }

  async getToken(): Promise<string> {
    const data = await this.#signedGet<LastFmAuthToken>(
      {
        method: 'auth.getToken',
        api_key: LASTFM_API_KEY,
      },
      'getToken',
    );

    return data.token;
  }

  async getSession(token: string): Promise<{ key: string; name: string }> {
    const data = await this.#signedGet<LastFmSession>(
      {
        method: 'auth.getSession',
        api_key: LASTFM_API_KEY,
        token,
      },
      'getSession',
    );

    return {
      key: data.session.key,
      name: data.session.name,
    };
  }

  async scrobble(
    sessionKey: string,
    artist: string,
    track: string,
    timestamp: number,
    album?: string,
    duration?: number,
  ): Promise<LastFmScrobbleResponse> {
    return this.#signedPost<LastFmScrobbleResponse>(
      {
        method: 'track.scrobble',
        api_key: LASTFM_API_KEY,
        sk: sessionKey,
        artist,
        track,
        timestamp: String(timestamp),
        ...optionalParams({
          album,
          duration: duration != null ? String(Math.round(duration)) : undefined,
        }),
      },
      'scrobble',
    );
  }

  async getSimilarTracks(
    artist: string,
    track: string,
  ): Promise<LastFmSimilarTracksResponse> {
    return this.#get<LastFmSimilarTracksResponse>(
      { method: 'track.getSimilar', artist, track },
      'getSimilarTracks',
    );
  }

  async getArtistTopTracks(
    artist: string,
  ): Promise<LastFmTopTracksResponse> {
    return this.#get<LastFmTopTracksResponse>(
      { method: 'artist.getTopTracks', artist },
      'getArtistTopTracks',
    );
  }

  async getSimilarArtists(
    artist: string,
  ): Promise<LastFmSimilarArtistsResponse> {
    return this.#get<LastFmSimilarArtistsResponse>(
      { method: 'artist.getSimilar', artist },
      'getSimilarArtists',
    );
  }

  async updateNowPlaying(
    sessionKey: string,
    artist: string,
    track: string,
    album?: string,
    duration?: number,
  ): Promise<LastFmNowPlayingResponse> {
    return this.#signedPost<LastFmNowPlayingResponse>(
      {
        method: 'track.updateNowPlaying',
        api_key: LASTFM_API_KEY,
        sk: sessionKey,
        artist,
        track,
        ...optionalParams({
          album,
          duration: duration != null ? String(Math.round(duration)) : undefined,
        }),
      },
      'updateNowPlaying',
    );
  }
}
