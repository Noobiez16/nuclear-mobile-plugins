import md5 from 'blueimp-md5';

export const createApiSignature = (
  params: Record<string, string>,
  secret: string,
): string => {
  const sortedKeys = Object.keys(params).sort();
  const paramString = sortedKeys
    .map((key) => `${key}${params[key]}`)
    .join('');
  return md5(`${paramString}${secret}`);
};
