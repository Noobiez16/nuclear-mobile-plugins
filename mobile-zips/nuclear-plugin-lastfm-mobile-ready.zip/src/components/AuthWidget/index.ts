export { LastFmAuthWidget } from './AuthWidget';
