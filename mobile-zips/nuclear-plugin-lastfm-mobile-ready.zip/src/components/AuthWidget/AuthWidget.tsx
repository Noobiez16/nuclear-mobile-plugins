import type { NuclearPluginAPI } from '@nuclearplayer/plugin-sdk';
import type { CustomWidgetProps } from '@nuclearplayer/plugin-sdk';
import { Button } from '@nuclearplayer/ui';
import type { FC } from 'react';

import { LASTFM_API_KEY, LASTFM_AUTH_URL } from '../../config';
import { LastFmClient } from '../../client';
import type {
  LastFmAuthState,
  LastFmConnectedAuth,
  LastFmPendingAuth,
} from '../../types';

const LASTFM_RED = '#d51007';

const lastfmButtonStyle = {
  backgroundColor: LASTFM_RED,
  color: 'white',
} as const;

const isConnected = (
  state: LastFmAuthState,
): state is LastFmConnectedAuth =>
  state != null && 'sessionKey' in state;

const isPending = (
  state: LastFmAuthState,
): state is LastFmPendingAuth =>
  state != null && 'waitingForApproval' in state;

export const LastFmAuthWidget: FC<CustomWidgetProps<NuclearPluginAPI>> = ({
  value,
  setValue,
  api,
}) => {
  const authState = value as LastFmAuthState;

  const handleConnect = async () => {
    try {
      const client = new LastFmClient(api.Http.fetch);
      const token = await client.getToken();

      const authUrl = `${LASTFM_AUTH_URL}?api_key=${LASTFM_API_KEY}&token=${token}`;
      await api.Shell.openExternal(authUrl);

      setValue({ token, waitingForApproval: true });
    } catch (error) {
      api.Logger.error(
        `Failed to connect to Last.fm: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  };

  const handleCompleteAuth = async () => {
    if (!isPending(authState)) {
      return;
    }

    try {
      const client = new LastFmClient(api.Http.fetch);
      const session = await client.getSession(authState.token);

      setValue({
        sessionKey: session.key,
        username: session.name,
      });
    } catch (error) {
      api.Logger.error(
        `Failed to complete Last.fm auth: ${error instanceof Error ? error.message : String(error)}`,
      );
      setValue(null);
    }
  };

  const handleDisconnect = () => {
    setValue(null);
  };

  if (isConnected(authState)) {
    return (
      <div className="flex items-center gap-3">
        <span>
          Connected as <strong>{authState.username}</strong>
        </span>
        <Button
          variant="secondary"
          size="sm"
          onClick={handleDisconnect}
        >
          Disconnect
        </Button>
      </div>
    );
  }

  if (isPending(authState)) {
    return (
      <div className="flex flex-col items-start gap-3">
        <span className="opacity-80">
          Approve the connection in your browser, then click below.
        </span>
        <Button
          style={lastfmButtonStyle}
          onClick={handleCompleteAuth}
        >
          Complete authentication
        </Button>
      </div>
    );
  }

  return (
    <Button
      className="self-start"
      style={lastfmButtonStyle}
      onClick={handleConnect}
    >
      Connect to Last.fm
    </Button>
  );
};
