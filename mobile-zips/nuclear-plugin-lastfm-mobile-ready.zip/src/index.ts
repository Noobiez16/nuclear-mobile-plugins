import type {
  NuclearPlugin,
  NuclearPluginAPI,
  Track,
} from '@nuclearplayer/plugin-sdk';

import { LastFmClient } from './client';
import { LastFmAuthWidget } from './components/AuthWidget';
import { SETTINGS, WIDGET_ID } from './config';
import { createDiscoveryProvider } from './discovery/provider';
import type { LastFmAuthState } from './types';
import { artistName } from './utils';

let cleanup: (() => void) | null = null;

const plugin: NuclearPlugin = {
  async onEnable(api: NuclearPluginAPI) {
    const client = new LastFmClient(api.Http.fetch);
    const unsubscribers: (() => void)[] = [];

    await api.Settings.register([
      {
        id: SETTINGS.AUTH_WIDGET,
        title: 'Last.fm Account',
        description: 'Connect your Last.fm account to enable scrobbling',
        category: 'Last.fm',
        kind: 'custom',
        widgetId: WIDGET_ID,
        default: null,
      },
      {
        id: SETTINGS.SCROBBLING_ENABLED,
        title: 'Enable scrobbling',
        description: 'Scrobble tracks to your Last.fm profile',
        category: 'Last.fm',
        kind: 'boolean',
        default: true,
        widget: { type: 'toggle' },
      },
    ]);

    api.Settings.registerWidget(WIDGET_ID, LastFmAuthWidget);

    const discoveryProviderId = api.Providers.register(
      createDiscoveryProvider(api, client),
    );

    const getSessionKey = async (): Promise<string | null> => {
      const authState = await api.Settings.get<LastFmAuthState>(
        SETTINGS.AUTH_WIDGET,
      );
      if (authState && 'sessionKey' in authState) {
        return authState.sessionKey;
      }
      return null;
    };

    const isScrobblingEnabled = async (): Promise<boolean> => {
      const enabled = await api.Settings.get<boolean>(
        SETTINGS.SCROBBLING_ENABLED,
      );
      return enabled !== false;
    };

    const unsubTrackFinished = api.Events.on(
      'trackFinished',
      async (track: Track) => {
        try {
          const artist = artistName(track);
          api.Logger.info(`Track finished: ${artist} - ${track.title}`);

          const sessionKey = await getSessionKey();
          if (!sessionKey) {
            api.Logger.debug('No session key, skipping scrobble');
            return;
          }

          const enabled = await isScrobblingEnabled();
          if (!enabled) {
            api.Logger.debug('Scrobbling disabled, skipping');
            return;
          }

          const timestamp = Math.floor(Date.now() / 1000);
          const durationSeconds = track.durationMs
            ? Math.round(track.durationMs / 1000)
            : undefined;

          await client.scrobble(
            sessionKey,
            artist,
            track.title,
            timestamp,
            track.album?.title,
            durationSeconds,
          );
          api.Logger.info(`Scrobbled: ${artist} - ${track.title}`);
        } catch (error) {
          api.Logger.error(
            `Failed to scrobble: ${error instanceof Error ? error.message : String(error)}`,
          );
        }
      },
    );
    unsubscribers.push(unsubTrackFinished);

    const unsubTrackStarted = api.Events.on(
      'trackStarted',
      async (track: Track) => {
        try {
          const sessionKey = await getSessionKey();
          if (!sessionKey) {
            return;
          }

          const enabled = await isScrobblingEnabled();
          if (!enabled) {
            return;
          }

          const artist = artistName(track);
          const durationSeconds = track.durationMs
            ? Math.round(track.durationMs / 1000)
            : undefined;

          await client.updateNowPlaying(
            sessionKey,
            artist,
            track.title,
            track.album?.title,
            durationSeconds,
          );
          api.Logger.debug(`Now playing: ${artist} - ${track.title}`);
        } catch (error) {
          api.Logger.error(
            `Failed to update now playing: ${error instanceof Error ? error.message : String(error)}`,
          );
        }
      },
    );
    unsubscribers.push(unsubTrackStarted);

    cleanup = () => {
      unsubscribers.forEach((unsub) => unsub());
      api.Providers.unregister(discoveryProviderId);
      api.Settings.unregisterWidget(WIDGET_ID);
    };
  },

  onDisable() {
    cleanup?.();
    cleanup = null;
  },
};

export default plugin;
