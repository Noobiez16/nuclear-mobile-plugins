export type LastFmAuthToken = {
  token: string;
};

export type LastFmSession = {
  session: {
    name: string;
    key: string;
    subscriber: number;
  };
};

export type LastFmError = {
  error: number;
  message: string;
};

export type LastFmScrobbleResponse = {
  scrobbles: {
    scrobble: {
      track: { corrected: string; '#text': string };
      artist: { corrected: string; '#text': string };
      album: { corrected: string; '#text': string };
      ignoredMessage: { code: string; '#text': string };
      timestamp: string;
    };
    '@attr': {
      accepted: number;
      ignored: number;
    };
  };
};

export type LastFmNowPlayingResponse = {
  nowplaying: {
    track: { corrected: string; '#text': string };
    artist: { corrected: string; '#text': string };
    album: { corrected: string; '#text': string };
    ignoredMessage: { code: string; '#text': string };
  };
};

export type LastFmPendingAuth = {
  token: string;
  waitingForApproval: true;
};

export type LastFmConnectedAuth = {
  sessionKey: string;
  username: string;
};

export type LastFmAuthState = LastFmPendingAuth | LastFmConnectedAuth | null;

export type LastFmSimilarTrack = {
  name: string;
  artist: { name: string; mbid?: string };
  match: number;
  image?: Array<{ '#text': string; size: string }>;
};

export type LastFmSimilarTracksResponse = {
  similartracks: {
    track: LastFmSimilarTrack[];
  };
};

export type LastFmSimilarArtist = {
  name: string;
  match: number;
  image?: Array<{ '#text': string; size: string }>;
};

export type LastFmSimilarArtistsResponse = {
  similarartists: {
    artist: LastFmSimilarArtist[];
  };
};

export type LastFmTopTrack = {
  name: string;
  artist: { name: string };
  image?: Array<{ '#text': string; size: string }>;
};

export type LastFmTopTracksResponse = {
  toptracks: {
    track: LastFmTopTrack[];
  };
};
