import type { Track } from '@nuclearplayer/plugin-sdk';

export const artistName = (track: Track): string =>
  track.artists.map((artist) => artist.name).join(', ');
