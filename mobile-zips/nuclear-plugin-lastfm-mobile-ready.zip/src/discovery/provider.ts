import type {
  DiscoveryOptions,
  DiscoveryProvider,
  NuclearPluginAPI,
  Track,
} from '@nuclearplayer/plugin-sdk';

import type { LastFmClient } from '../client';
import { artistName } from '../utils';
import { sliceByRatio, weightedRandomPick } from './weighted-random';

const PROVIDER_ID = 'lastfm-discovery';

const trackKey = (artist: string, title: string): string =>
  `${artist.toLowerCase()}::${title.toLowerCase()}`;

const createContextKeySet = (context: Track[]): Set<string> =>
  new Set(context.map((track) => trackKey(artistName(track), track.title)));

const toNuclearTrack = (artist: string, title: string): Track => ({
  title,
  artists: [{ name: artist, roles: ['main'] }],
  source: { provider: PROVIDER_ID, id: trackKey(artist, title) },
});

export const createDiscoveryProvider = (
  api: NuclearPluginAPI,
  client: LastFmClient,
): DiscoveryProvider => ({
  id: PROVIDER_ID,
  kind: 'discovery',
  name: 'Last.fm',

  async getRecommendations(
    context: Track[],
    options: DiscoveryOptions,
  ): Promise<Track[]> {
    if (!context) {
      return [];
    }

    const variety = options.variety;

    const result = await findSimilarTracks(client, context, variety);
    if (result.length) {
      return result;
    }

    return findViaRelatedArtists(client, context, variety);
  },
});

const findSimilarTracks = async (
  client: LastFmClient,
  context: Track[],
  variety: number,
): Promise<Track[]> => {
  const responses = await Promise.all(
    context.map((track) =>
      client.getSimilarTracks(artistName(track), track.title),
    ),
  );

  const existing = createContextKeySet(context);
  const candidates = responses
    .flatMap((response) => response.similartracks.track)
    .filter((track) => !existing.has(trackKey(track.artist.name, track.name)));

  const pool = sliceByRatio(candidates, variety);
  if (!pool.length) {
    return [];
  }

  const pick = weightedRandomPick(pool);
  return [toNuclearTrack(pick.artist.name, pick.name)];
};

const findViaRelatedArtists = async (
  client: LastFmClient,
  context: Track[],
  variety: number,
): Promise<Track[]> => {
  const lastTrack = context[context.length - 1];
  const response = await client.getSimilarArtists(artistName(lastTrack));
  const artists = sliceByRatio(response.similarartists.artist, variety);
  if (!artists.length) {
    return [];
  }

  const pickedArtist = artists[Math.floor(Math.random() * artists.length)];
  const topTracks = await client.getArtistTopTracks(pickedArtist.name);
  const existing = createContextKeySet(context);
  const candidates = topTracks.toptracks.track.filter(
    (track) => !existing.has(trackKey(track.artist.name, track.name)),
  );

  if (!candidates.length) {
    return [];
  }

  const pick = candidates[Math.floor(Math.random() * candidates.length)];
  return [toNuclearTrack(pick.artist.name, pick.name)];
};
