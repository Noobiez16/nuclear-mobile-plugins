export const sliceByRatio = <T>(items: T[], ratio: number): T[] =>
  items.slice(0, Math.round(ratio * (items.length - 1)) + 1);

export const weightedRandomPick = <T extends { match: number }>(
  items: T[],
): T => {
  const totalWeight = items.reduce((sum, item) => sum + item.match, 0);

  let roll = Math.random() * totalWeight;
  for (const item of items) {
    roll -= item.match;
    if (roll <= 0) {
      return item;
    }
  }

  return items[items.length - 1];
};
