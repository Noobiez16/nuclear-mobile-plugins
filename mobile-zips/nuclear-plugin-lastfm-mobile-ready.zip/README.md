# Last.fm Plugin for Nuclear

Scrobble tracks and update "Now Playing" on your [Last.fm](https://www.last.fm/) profile.

## Features

- Scrobbles tracks when they finish playing
- Updates "Now Playing" status when a track starts
- One-click authentication via Last.fm's web authorization flow
- Per-user toggle to enable/disable scrobbling

## Installation

Install from the Nuclear plugin browser.

## Building

This plugin uses a custom widget (React component) for the auth flow, so it needs to be pre-bundled:

```bash
pnpm install
pnpm build
```

The build step uses esbuild to bundle the plugin source and its dependencies into a single CJS file at `dist/index.js`. React, the plugin SDK, and Nuclear UI are kept external.

## License

AGPL-3.0-only
