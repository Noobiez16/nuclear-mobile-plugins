# YouTube Playlists Plugin for Nuclear

A playlist provider plugin that lets you import YouTube playlists by URL. Requires [yt-dlp](https://github.com/yt-dlp/yt-dlp) installed on your system.

## Installation

Install from the Nuclear plugin browser.

## License

AGPL-3.0-only
