export const PROVIDER_ID = 'youtube-playlists';
export const PROVIDER_NAME = 'YouTube Playlists';
